

<?php $__env->startSection('content'); ?>
    <home-component></home-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\urlShortner\resources\views/home.blade.php ENDPATH**/ ?>