<template>
    <div class="container-fluid">
        <div class="row footer margin-right-0">
            <div class="col-md-12 text-center">
                <p> URL Shortner &copy; Md. Meher Ullah</p>
            </div>

        </div>
    </div>
</template>

<script>
export default {

    mounted() {

    }
}
</script>
